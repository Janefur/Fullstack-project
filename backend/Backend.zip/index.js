"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cors_1 = __importDefault(require("cors"));
const express_1 = __importDefault(require("express"));
const dotenv_1 = __importDefault(require("dotenv"));
const pg_1 = require("pg");
dotenv_1.default.config();
const client = new pg_1.Client({
    connectionString: process.env.PGURI,
});
client.connect();
const app = (0, express_1.default)();
app.use((0, cors_1.default)());
app.use(express_1.default.json());
/**----GET alla barn---- */
app.get("/", (_req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { rows: children } = yield client.query("SELECT * FROM kids");
        const countResult = yield client.query("SELECT COUNT(*) FROM kids");
        const count = parseInt(countResult.rows[0].count, 10);
        res.send({ children: children, count: count });
    }
    catch (err) {
        res.status(400).send("Kunde inte hämta alla barn" + err);
    }
}));
/**----GET alla avdelningar---- */
app.get("/departments", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { rows: departments } = yield client.query("SELECT * FROM departments");
        res.send(departments);
    }
    catch (err) {
        res.status(400).send("Kunde inte hämta avdelningarna" + err);
    }
}));
/**----GET en avdelning---- */
app.get("/departments/:id", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const idParam = req.params.id;
    if (!idParam) {
        return res.status(400).send("Id saknas");
    }
    try {
        const result = yield client.query("SELECT * FROM departments WHERE id= $1", [idParam]);
        res.status(200).send(result.rows[0]);
    }
    catch (err) {
        console.error("Ett fel uppstod", err);
        res.status(400).send("Kunde inte hämta avdelning");
    }
}));
/**----GET alla barn på en avdelning---- */
app.get("/departments/:id/children", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const departmentId = req.params.id;
    if (!departmentId) {
        return res.status(400).send("AvdelningsID saknas");
    }
    try {
        const check = yield client.query("SELECT * FROM kids WHERE department = $1", [departmentId]);
        if (check.rowCount === 0) {
            return res.status(404).send("Avdelningen finns inte");
        }
        const result = yield client.query("SELECT * FROM kids WHERE department = $1", [departmentId]);
        res.send(result.rows);
    }
    catch (err) {
        res.status(400).send("Kunde inte hämta barnen" + err);
    }
}));
/**----GET all data för att kunna söka---- */
app.get("/all-data", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tables = yield client.query("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'");
        const allData = {};
        for (let row of tables.rows) {
            const tableName = row.table_name;
            const data = yield client.query(`SELECT * FROM ${tableName}`);
            allData[tableName] = data.rows;
        }
        res.send(allData);
    }
    catch (err) {
        res.status(400).send("Kunde inte hämta data" + err);
    }
}));
/*-----POST----*/
app.post("/", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { first_name, last_name, age, adress, department } = req.body;
    try {
        yield client.query(`INSERT INTO kids (first_name, last_name, age, adress, department)
    VALUES ($1, $2, $3, $4, $5)`, [first_name, last_name, age, adress, department]);
        const { rows } = yield client.query("SELECT * FROM kids");
        res.send({ message: "Nytt barn har lagts till", count: rows.length });
    }
    catch (err) {
        res.status(400).send("Kunde inte lägga till barn" + err);
    }
}));
/**----DELETE barn---- */
app.delete("/:id", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const childId = req.params.id;
    if (!childId) {
        return res.status(400).send("Barnets ID saknas");
    }
    // Måste da bort foreign key i den andra tabellen samtidigt. CASCADE! De nya barn jag lägger till går att ta bort för de har ingen foreignkey. DELETE ON CASCADE
    try {
        yield client.query("DELETE FROM kids WHERE id = $1", [childId]);
        res.status(200).send();
    }
    catch (err) {
        res.status(400).send("Kunde inte ta bort barnet" + err);
    }
}));
app.listen(3000, () => {
    console.log("Webbtjänsten kan nu ta emot anrop.");
});
